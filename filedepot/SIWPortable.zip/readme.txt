**********************************************************************
*
*	Copyright (c) 2005-2019 Topala Software Solutions
*       System Information for Windows - SIW 2019 v9.1.0409
*
**********************************************************************

**********************************************************************
*  CONTENTS OF THIS DOCUMENT
**********************************************************************
This README.TXT file describes SIW. The following topics are discussed:
  1. Overview
  2. What's New?
  3. Installation
  4. Copyright and Contact Information



**********************************************************************
*  1. Overview
**********************************************************************

SIW is an advanced System Information utility that gathers detailed information about your system properties and settings. 
A utility that includes detailed specs for Motherboard, BIOS, CPU, Devices, Memory, Video, Drives, Ports.
It displays information about Operating System, Installed Programs, Processes, Services, 
Product Key (CD key), Serial Numbers, Users, Open Files, System uptime, Users, Network, Network Shares.
SIW also displays currently active network connections, Passwords hidden behind asterisks, installed codecs.



**********************************************************************
*  2. What's New?
**********************************************************************

* SIW 2019 v9.1.0409
- Fixed a crash on Windows (TM) 10 Preinstallation Environment without Pdh.dll library.
- Added Windows Firewall module.
- Updated Operating System module:
    Added Installation History.
    Added Windows Sandbox detection.
- Updated Extended Information about Network module.
- Updated Battery and Power Policy module.
- Updated Devices database.
- Minor enhancements and compatibility fixes.
 
*	SIW 2019 v9.0.0115
- Fixed a "Missing Administrator Privileges" warning.
- Fixed an ACPI bug on HP EliteBook 84XX and 85XX.
- Fixed URL Explorer bug.
- Fixed Refresh bug.
- ISO 6801 Date/Time format.
- Updated Devices database.
- Minor enhancements and compatibility fixes.

*   SIW 2018 v8.4.1120
- Fixed a license error validation (33) when siw is executed from an USB memory stick.
- Fixed an Installed Updates bug.
- Updated Operating System module:
    Skip Ahead 19H1 Support.
    Windows Server 2019 support.
- Updated Software modules.
    System Directories.
    Applications.
- Updated Passwords module.
    Firefox Portable Support. SIW now automatically detects the portable version of Firefox that is currently running in the background, if it cannot find any other installation of Firefox.
- Updated CPU module:
    Intel 9th generation Core family (Coffee Lake 9900K, 9700K, 9600K, 960, 9500 and 9400).
    Intel Coffee Lake-U processors.
- Improved error messages.
- Updated Devices database.
- Minor enhancements and compatibility fixes.
 
*   SIW 2018 v8.3.0729
- Customized SIW Home for Computer Bild Magazine

*   SIW 2018 v8.3.0710
- Updated Passwords module.
    Improved support for Firefox 61.
- Improved error messages.
- Renamed SIW Pro to SIW Home; renamed SIW DEMO to SIW Trial.
- Updated Devices database.
- Minor enhancements and compatibility fixes.
 
*   SIW 2018 v8.2.0502
- Updated Operating System module:
    Added support for Windows 10 1803 (April 2018 Update).
    Preliminary Windows Server 2019 support.
    Preliminary Windows 10 Redstone 5 support.
- Updated Passwords module.
    Firefox 59.
- Updated CPU module:
    Intel new Coffee Lake desktop and mobile processors.
    AMD desktop Raven Ridge APU (AM4).
    Intel Xeon Phi Knight Landing preliminary support.
- Fixed Create Report bug.
- Updated Devices database.
- Minor enhancements and compatibility fixes.
 
*	SIW 2018 v8.1.0227
- Added Office 2019 preliminary support.
- Updated Slovenian Translation.
- Updated Passwords module.
	Firefox 58.
	Login password for WinXP, Vista and Windows 7
- Added Antivirus Hook Check.
- Updated Options/Warnings dialog.
- Renamed 64 bit build to siw64.exe.
- Updated devices database.
- Minor enhancements and compatibility fixes.

*	SIW 2018 v8.0.0106
- Updated Passwords module.
- Updated Memory module.
- Updated Network Adapters module.
- Updated devices database.
- Minor enhancements and compatibility fixes.

*	SIW 2017 v7.8.1111
- Updated devices database.
- Minor enhancements and compatibility fixes.

*	SIW 2017 v7.7.1029
- New tool: siw2odbc (c) Andrei Topala.
- Updated Operating System module:
	Added Windows Server 1709 detection.
	Added Windows 10 Pro for Workstations detection.
- Updated CPU module:
	Intel Coffee Lake processors and Z370 platform.
	Intel Skylake-X HCC processors.
	Intel Xeon Skylake-SP and Xeon W Skylake processors.
- Fixed a short report crash.
- Updated devices database.
- Minor enhancements and compatibility fixes.

*	SIW 2017 v7.6.0912
- Added 64-bit build for Technician's Version.
- Updated Operating System module:
	Fixed an "error code 0x57 (87)" on Windows 10 Insider.
    Improved support for Windows PE.
- Updated devices database.
- Minor enhancements and compatibility fixes.
     
*	SIW 2017 v7.5.0807
- Updated Operating System module:
	Added Windows Server 2016 Insider detection.
    Added "Skip ahead" Windows 10 detection.
- Updated CPU module:
    Intel Core X processors (KBL-X and SKL-X).
    AMD Bristol Ridge.
- Updated Video module:
    Improved monitor detection.
- Workaround for threads/processes execution policy (Windows 10).
- Updated devices database.
- Minor enhancements and compatibility fixes.
     
*    SIW 2017 v7.4.0705
- Updated Passwords module:
	Firefox v54.0.1
- Updated Devices database.
- Minor enhancements and compatibility fixes.

*    SIW 2017 v7.3.0629
- Updated Operating System module:
	Added Windows 10 S detection.
	Added LTSB detection.
- Updated CPU module:
	AMD ThreadRipper.
	AMD Ryzen 5 and Ryzen 3.
- Added .NET Core detection.
- Updated Devices database.
- Minor enhancements and compatibility fixes.

*    SIW 2017 v7.2.0420
- Updated Operating System module:
	Improved support for Windows 10 Creators Update.
	Preliminary support for Windows 10 Redstone 3.
- Updated CPU module:
	AMD Ryzen processors support.
	AMD Polaris GPU support improved.
- Improved translations.
- Fixed a TimeZoneInformation bug.
- Fixed a Remote License Report bug.
- Updated Devices database.
- Minor enhancements and compatibility fixes.

*    SIW 2017 v7.1.0323
- Updated Operating System module:
	Improved support for Windows 10 Creators Update.
	Added Unified Update Platform detection.
	Added "Windows Insider" detection.
- Fixed a crash (Reports on WinXP).
- Improved translations.
- Updated Devices database.
- Minor enhancements and compatibility fixes.

*    SIW 2017 v7.0.0214
- Updated Licenses module.
- Updated Remote Licenses (Tools) module. 
- Updated Passwords module 
- Updated .NET 4.7 detection. 
- Updated CPU module:
	Intel Kaby Lake processors. 
	AMD Embedded G and R-series processors. 
	DMP Vortex86 DX3. 
- French XML Report bugfix.
- Minor UI interface changes.
- Updated Devices database.
- Minor enhancements and compatibility fixes.

*    SIW 2016 v6.4.0928
- Updated CPU module:
	Preliminary support for Intel Kaby Lake.
	Preliminary support for AMD Bristol Ridge processors.
- Updated NT Services module:
	Added Service Start Name.
- Updated .NET detection.
- Updated Firefox passwords detection.
- Updated devices database.
- Minor enhancements and compatibility fixes.

*    SIW 2016 v6.3.0712
- Updated Operating System module:
	Improved support for Windows 10 Anniversary Edition.
- Updated Memory module (DDR4)
- Updated devices database.
- Minor enhancements and compatibility fixes.


*    SIW 2016 v6.2.0511
- Updated Operating System module:
	Added support for Windows 10 Anniversary Edition.
	Added support for Windows 2016 Technical Preview 5.
- Updated CPU module:
	Intel Broadwell-E/EP processors
- Improved support for NVMe SSDs.
- Updated Memory module
- Updated devices database.
- Minor enhancements and compatibility fixes.


*    SIW 2016 v6.1.0202
- Improved Microsoft Surface Book support.
- Updated CPU module:
	Intel Skylake Pentium, Celeron and Core m3/m5/m7 support.
	Intel Broadwell-E preliminary support.
	AMD A10-7890K APU.
- Improved support for NVMe SSDs.
- Improved Windows 10 support.
- Updated devices database.
- Minor enhancements and compatibility fixes.

*    SIW 2016 v6.0.0106
- Updated Operating System module:
	Improved Windows 10 build detection.
- Updated Passwords module:
	Added WinSCP detection.
- Updated devices database.
- Minor enhancements and compatibility fixes.

*    SIW 2015 v5.5.1208
- Updated Operating System module:
	Added support for Windows 10 Version 1511.
	Added support for Windows 2016 Technical Preview 4.
- Added MMC Snap-Ins module.
- Added .Net 4.6.1 detection.
- Updated Installed Updates module.
- Improved multithreading.
- Updated devices database.
- Minor enhancements and compatibility fixes.

*    SIW 2015 v5.4.1030
- Updated Passwords module.
- Updated File Associations module.
- Improved Reports performance.
- Updated devices database.
- Minor enhancements and compatibility fixes.

*    SIW 2015 v5.3.0828
- Added DirectX 12 detection.
- Added .Net 4.6 detection.
- Improved Windows 10 support.
- Updated devices database.
- Minor enhancements and compatibility fixes.

*    SIW 2015 v5.2.0707
- Updated Sensors module.
- Updated Video module.
- Updated File Associations module.
- Updated Installed Programs module.
- Updated Extended Network Information module.
- Updated CPU module:
	Latest models of Intel Broadwell.
	Latest models of Intel Skylake.
- Updated devices database.
- Minor enhancements and compatibility fixes.

*    SIW 2015 v5.1.0312
- Updated CPU module:
	Intel Core M processors.
	Preliminary support for Intel Skylake.
- Updated Memory module.
	Preliminary support for DDR4 memory.
- Updated Licenses module:
    UEFI OEM Original Product Key.
- Updated Passwords module.
	Firefox 32 and newer.
	SeaMonkey.
	Outlook (Exchange Passwords).
- Updated Languages.
- Updated devices database.
- Minor enhancements and compatibility fixes.

*    SIW 2014 v4.10.1016
- Added support for Windows 10 Technical Preview.
- Updated CPU module:
	AMD Athlon X2 450, Athlon X4 840 and Athlon X4 860K (Kaveri) 
	AMD FX-8370, FX-8370E, FX-8320E (Vishera) 
	Improved AMD FCH detection.
- Improved support for Intel X99 chipset.
- Updated devices database.
- Minor enhancements and compatibility fixes.

*    SIW 2014 v4.9.0904
- Added Hyper-V module.
- Updated CPU module:
	Intel Haswell-E processors.
	Intel i7-5960X, i7-5930K, i7-5820K, i7-4790K, i5-4690K, Pentium G3258.
	Improved AMD FCH detection.
- Updated Network Adapters module.
- Updated Network Information module.
- Merged SMB Connections and RAS Connections into Network Connections.
- Added Microsoft .NET Framework 4.5.2 detection.
- Added DirectX 11.1, 11.2 and 12.0 detection.
- Updated devices database.
- Minor enhancements and compatibility fixes.

*    SIW 2014 v4.8.0427
- Added support for Windows 8.1 Update and Windows 2012 R2 Update.
- Added SMB Connections module (Windows 8 or newer).
- Updated CPU module:
	Changed "CPU Info" label to "CPU".
	Added support for AMD A6-6420K, A4-6320, A4-4020.
	Added support for AMD Athlon 5350 &amp; 5150, Sempron 3850 &amp; 2650 Kabini.
	Added support for Intel Core i7-4770R and Core i5-4570R Crystal Well.
- Updated Storage Devices module.
	Improved detection for Advanced Format Mode.
- Updated Shares module.
- Updated Devices module.
- Updated PCI module.
- Updated Printers module.
- Updated Passwords module:
	Enhanced Firefox detection.
	Enhanced Outlook Express decoding.
- Updated Operating System module:
	Added support for Windows 8.1 Update and Windows 2012 R2 Update.
	Added Windows To Go detection.
- Fixed Bulgarian language.
- Updated devices database.
- Minor enhancements and compatibility fixes.

*    SIW 2014 v4.7.0130
- Added Active Directory module (Computers, Groups, Users).
- Updated CPU and Sensors modules:
	Improved support of Intel Silvermont (Bay Trail).
	Added support for AMD Kaveri APUs (A10-7850K, A10-7800, A10-7700K, A8-7600, A6-7400K, A4-7300).
	Added support for Intel i7-4790, i5-4690, i5-4590, i5-4460.
	Added support for Intel Celeron Haswell (G1830, G1820).
	Added support for Intel series 9 chipset (Z97).
	Added Microcode for Intel processors.
	Added support for Nuvoton NCT6106 and SMSC SCH5636 SIOs (Fujitsu motherboards).
- Updated Storage Devices module.
- Updated Logical Disks module.
- Updated devices database.
- Minor enhancements and compatibility fixes.

*    SIW 2013 v4.6.1024a
- Added Firefox 24 password decoding.

*    SIW 2013 v4.6.1024
- Updated CPU module:
    Support for Intel Core i3-4xxx, Core ix-4xxxHQ "Crystalwell", Pentium "Haswell" G3430, G3420, G3220, Core i7-3910K processors. 
    Support for Intel 8-series chipset. 
    Intel Xeon E5-2600 V2, Core i3-4xxx, Core i7-3910K processors. 
    Intel Ivy Bridge-E/EP/EX support improved. 
    Intel Atom Bay Trail-T preliminary support. 
    Improved support for Intel Silvermont (Bay Trail). 
    AMD Opteron 3200 and 3300 series. 
- Updated Sensors module:
    Support for ITE IT8603, IT8323, IT8732 SIOs. 
    ITE IT8603 and IT8623 SIOs (Asus FM2+ motherboards). 
- Updated Microsoft .NET Detection. 
- Fixed installer issues (SIW Pro only):
    ERR_NOT_INSTALLED error. 
    "invalid instruction" crash for very old processors (like Pentium III). 
- Updated devices database. 
- Minor enhancements and compatibility fixes. 

*    SIW 2013 v4.5.0725a - Bugfix Build
- Re-added support for other languages.
- Removed a debug dialog box (HTML Report).

*    SIW 2013 v4.5.0725
- Added support for Windows 8.1 and Windows 2012 R2. 
- Updated Passwords module (added Internet Explorer 10, 11). 
- Updated Logical Disks module. 
- Updated CPU module:
    AMD Opteron X1150 and X2150, FX-9590 and FX-9370 processors. 
    Intel 4xxxHQ "Crystalwell", Pentium "Haswell" G3430, G3420, G3220 processors. 
- Improved Windows 2012 (R2) Server Core detection. 
- Updated devices database. 
- Minor enhancements and compatibility fixes. 

*    SIW 2013 v4.4.0514
- Updated CPU module:
    Intel Atom "Cloverview" and Ivy Bridge-E/EP/EX CPUs.
    AMD Richland APUs.
- Updated Sensors module:
    Microsoft Surface Pro support.
    Intel Pentium & Celeron "Ivy Bridge" CPUs support.
    Intel Ivy-Bridge-E/EP/EX and Haswell CPUs support.
    AMD Richland CPUs support.
    ITE IT8732 LPCIO chip support.
- Updated Video module.
- Updated devices database.
- Minor enhancements and compatibility fixes.

*    SIW 2013 v4.3.0428
- Windows 8 64-bit (SIW 2013 Home Edition - Beta)

*    SIW 2013 v4.2.0412
- Added CrashRpt library (http://code.google.com/p/crashrpt/).
- Added UEFI detection.
- Updated Licenses module (AutoCAD).
- Updated Passwords module (Outlook 2013).
- Updated CPU module:
    Intel Pentium & Celeron "Ivy Bridge" CPUs.
    AMD Athlon X4 750K.
- Updated Sensors module:
    Report uncore power on Intel Sandy Bridge and Ivy Bridge processors.
    Improved monitoring on Intel Z77 and Z87 mainboards.
- Updated Memory module.
- Updated Event Viewer module (Time field).
- Preliminary support for Windows Blue.
- Bug fixes:
    0xC0000005 exceptions during first restart after registration.
    CSV/TXT Reports for Applications.
- Updated devices database.
- Minor enhancements and compatibility fixes.

*    SIW 2013 v4.1.0104
- Fixed a "CPU and Memory" / "Network Traffic" bug (see https://www.gtopala.com/forum/Thread-SIW-2013-bug)

*    SIW 2013 v4.1.0103
- Added "Tools --> Microsoft --> Change Product Key" menu (Windows 8 only).
- Added support for AMD "Vishera" processors, preliminary support for Intel Haswell and Ivy Bridge E/EP.
- Updated "Sensors" module for HP Z420.
- Updated "Network Adapters" module.
- Fixed a "Licenses" concurrency bug.
- Updated devices database.
- Minor enhancements and compatibility fixes.

*    v2012.10.04
- Updated Sensors module for Dell PowerEdge R710 Server.
- Improved speed on multi-core CPUs.
- Updated devices database.
- Minor enhancements and compatibility fixes.

*    v2012.07.27
- Added Unknown Devices (Network, Video).
- Updated Adobe and AutoCAD Licenses detection.
- Updated Installed Programs.
- Updated CPU module.
- Updated Network Information.
- Fixed XML Report bug (SIW Business Edition).
- Improved support for Japanese language.
- Updated devices database.
- Minor enhancements and compatibility fixes.

*    v2012.03.26
- Fixed "HTML Report".
- Added "Detailed Report" Option.
- Added "/details" "Command Line" Option.
- Updated "Passwords" Module.
    Added Firefox 11 passwords decoding.

*    v2012.03.23
- Updated "CPU" Module.
    Intel Core i5 2550K, 2450P and 2380P with no GPU.
    Intel Core i3/i5/i7 22 nm "Ivy Bridge" (37xx, 35xx, 34xx, 33xx, 32xx).
    Intel Core i7-3960X, 3930K and 3820 (Sandy Bridge-E) and X79 chipset.
    Intel Xeon E3 (SandyBridge-WS).
    Intel Z77 platform.
    AMD Opteron Interlagos and Valencia (Bulldozer).
    AMD FX-8140, FX-4150 and Mobile Llano (socket FS1).
    AMD "Trinity" APU Preliminary support.
- Updated "Sensors" Module.
    Improved voltages report for lot of new mainboards.
- Updated "Operating System" Module.
- Updated "Memory" Module.
- Updated "Printers" Module.
- Updated "Autorun" Module.
- Updated devices database.
- Minor enhancements and compatibility fixes.

*    v2012.01.06
- Added Modem Properties to "Ports" module.
- Added Safari passwords.
- Added Firefox 9.x passwords.
- Added Trillian 4.x-5.x passwords.
- Added support for new CPU and chipsets: AMD Opteron Interlagos and Valencia (Bulldozer); AMD SR56x0 I/O bridge and SP5100 southbridge (Maranello); Intel Core i7-3960X, 3930K and 3820 (SandyBridge-E); Intel X79 chipset (Patsburg); VIA Nano 1000/2000/3000, Eden X2, Nano X2/X3, QuadCore.
- Updated "BIOS" module.
- Updated "PCI" module.
- Updated "Groups and Users" module (moved from Software section to Network section).
- Updated "Neighborhood Scan" module.
- Updated "Installed Programs" module.
- Updated Google Chrome passwords.
- Improved support for Windows 8 Developer Preview.
- Updated devices database.
- Minor enhancements and compatibility fixes.

*    v2011.10.29
- Fixed Firefox passwords
- Fixed Chrome passwords
- Faster OS detection

*    v2011.10.28
- Added Windows 8 support.
- Updated "Applications" (5 times faster).
- Updated "Running Processes" module.
- Fixed c0000005 excetions (ActiveX and Network).
- Updated devices database.
- Minor enhancements and compatibility fixes.

*    v2011.09.16
- Added JSON Reporting.
- Added CPU SLAT detection (Windows 8 with Hyper-V: https://www.infoworld.com/t/virtualization/windows-8-hyper-v-will-require-new-hardware-172123).
- Added Indonesian (Bahasa Indonesia) language.
- Updated Ports module.
- Updated Logical Disks module.
- Updated Open Ports module.
- Updated Shell Extensions module.
- Improved multilanguage support.
- Updated devices database.
- Minor enhancements and compatibility fixes.

*    v2011 Build 0707
- Added Advanced Format Drives detection (http://www.windowsnetworking.com/articles_tutorials/Advanced-Format-Drives.html)
- Updated CPU Module: Support for Intel P67/H67/HM65/HM67/Q65/Q67/QS67 chipsets, Support for AMD FX "Bulldozer" (K15) and AMD Llano (K12) processor families, Preliminary support for Intel Sandy Bridge-EP processors, Added Turbo Boost (Intel) / Turbo CORE (AMD) detection.
- Updated Sensors Module: Support for MSI OEM sensor chip, Support for Nuvoton NCT6776F sensor chip, Support for Asustek P8P67-M mainboard.
- Updated devices database.
- Minor enhancements and compatibility fixes.

*    v2011 Build 0526
- Added "Adobe CS" license detection.
- Updated "Installed Programs" Module.
- Updated "Groups and Users" Module.
- Updated devices database.
- Minor enhancements and compatibility fixes.

*    v2011 Build 0428
- Added Security --> Audit Policy.
- Added Tools --> Microsoft --> Memory Diagnostic Tool.
- Added Windows SBS 2011 detection.
- Added License detection for Microsoft SQL Server 2005.
- Added License detection for Adobe Acrobat X.
- Added License detection for Adobe CS.
- Fixed License detection for Adobe Acrobat 9.
- Fixed AMD Phenom II X2 and AMD Phenom II X4 Speed detection.
- Fixed System Files module.
- Updated Operating System Module.
- Updated Applications Module.
- Updated Outlook Password detection.
- Updated Databases Module.
- Updated Motherboard Module.
- Updated BIOS Module.
- Updated CPU Module: Intel Xeon "Westmere-EX" support, GPU frequency report on Intel Sandy Bridge processor, AMD Zacate/Ontario processors support
- Updated Network Statistics Module.
- Updated devices database.
- Minor enhancements and compatibility fixes.

*    v2011 Build 0203
- Added "Regional Settings" --> "Installed Code Pages".
- Added VirtualBox 4 detection.
- Updated "Sensors" module.
- Updated "Installed Updates" and "Missing Updates".
- Fixed DirectX detection.
- Fixed Ping command.
- Updated devices database.
- Updated SIWViewer.
- Minor enhancements and compatibility fixes.

*    v2010 Build 1118
- Added Software Certificates.
- Added SSL and TLS support(/smtpSecurity command line option). Free email servers (Gmail, Yahoo, Hotmail, GMX, etc.) can be used.
- Added /zip command line option.
- Added Tools --> Microsoft Support Diagnostic Tool.
- New CPUs: Intel Core i3/i5/i7 "2000" series processors (Sandy Bridge), Intel Core i7 970 "Gulftown", AMD Phenom II, Athlon II and Sempron II "Caspian" processors.
- Added Jump List (Windows 7).
- Updated PCI module.
- Updated devices database.
- Minor enhancements and compatibility fixes.


*    v2010 Build 1021
- Added Slovenian Language.
- Added SMTP Authentication.
- Added Print support for many modules (Security, Regional Settings, Event Viewer, CPU, Memory, Sensors, Devices, 
	System Slots, Network Adapters, Video, Sound Devices, Storage Devices, Power Policy, Battery, 
	Resources, Extended Network Information).
- Updated Eureka!
- Updated Google Chrome Passwords.
- Updated Video Module (added supported resolutions).
- HTML Report uses UTF-8 encoding (instead of ISO-8859-1).
- The Report can be FTP-ed or HTTP-Post-ed.
- Updated devices database.
- Minor enhancements and compatibility fixes.


*    v2010 Build 0714
- Updated Licenses (Adobe Acrobat 9, AutoCAD 2010, Autocad LT 2009, Corel VideoStudio 12 Pro, Techsmith Camtasia Studio 5/6, etc.).
- Updated devices database.
- Minor enhancements and compatibility fixes.

*    v2010 Build 0616
- Licenses: Added Microsoft Office 2010 x64 support.
- Passwords: Added Wireless SSID/Password for Windows 7.
- Passwords: Added Google Picasa support.
- Updated Extended Network Information.
- CPU: Fixed a hyperthreading issue.
- Minor improvements and bug fixes.

*    v2010 Build 0512
- Licenses: Added Microsoft Office 2010 support.
- Passwords: Added Google Chrome support.
- Updated "CPU" module.
- Minor improvements and bug fixes.

*    v2010 Build 0428
- Updated "Security" module.
- Updated "Event Viewer" module.
- Added /quickreport option.
- Minor improvements and bug fixes.

*    v2010 Build 0311
- New "Hardware --> Resource" module.
- Minor improvements and bug fixes.

*    v2010 Build 0210
- New "Power Policy" module.
- New "Sound Device" module.
- New "Tools: Microsoft --> Open 'God Mode' Directory" module.
- Updated "Video" module.
- Updated "CPU" module.
- CPU: Intel Core i7 930 & 950, Core i7 980X "Gulftown", Xeon W3565, Intel Mobile Core i7/i5/i3 "Arrandale" (LV and ULV).
- CPU: AMD Phenom FX-5000, Athlon II X2/X3/X4, Athlon L110, AMD AM3 socket detection improved.
- VIA VX800 and VX855 chipsets support, ATI Radeon 2100 and Radeon X1250 support.
- Minor improvements and bug fixes.

*    v2009-11-13
- Secrets: Added Outlook 2000-2007 password recovery.
- Secrets: Added Firefox 3.5 support
- Secrets: Fixed Outlook Express passwords
- Added IPv6 support.
- Minor improvements and bug fixes.

*    v2009-10-22
- Windows 7 Compatible
- PortableApps
- DirectX detection on Win7
- Correct Splash Screen size if DPI != 96
- Scheduled Tasks for Vista and Windows 7
- Tools --> Hibernate Enable/Disable for Windows 7
- Fixed: CPU and Memory Usage
- Fixed: Installation Time
- Fixed: Wrong menu
- Fixed: Exception c0000096 when Sony Vegas 7 is installed on Vista 32
- Fixed: Empty messages in Event Viewer
- Minor improvements and bug fixes.

*    v2009-09-09
- Minor improvements and bug fixes.

*    v2009-07-28
- New laptops hardware monitors : Dell Latitude D400/D600/D830, Compal JHL90/91 & IFL90/91.
- Support for Intel Management Engine (HECI).
- NVIDIA nForce 980a chipset support.
- Intel Core i5 and Core i3 processors.
- Intel Atom Z530, Pentium DC E6300 (2.8GHz) and Core 2 Solo processors.
- Intel P55 and US15W chipsets preliminary support.
- AMD Phenom TWKR support.
- AMD Phenom X2 "Callisto" and Athlon X2 "Regor" processors.
- AMD Opteron 6-core "Istanbul" processor.
- New sensor chips : NS PC87366, Fintek F71889F, Maxim MAX1617.
- New "Tools --> MUICache Viewer" module.
- New "Tools --> URL Explorer --> Search History" module.
- Added Company info to Drivers and NT Services.
- Added "Process Description (Online)" right-click menu. It uses http://www.processlibrary.com
- Added "Command Line with parameter(s)" for "Running Processes".
- Added "Roles and Features" for Windows 2008.
- Updated Battery modele.
- Minor improvements and bug fixes.

*    v2009-05-18
- Updated Battery module.
- Updated Installed Programs module.
- Fixed XML Report.
- NVIDIA ION platform.
- Intel "Clarkdale" processor preliminary support.
- Preliminary support of Apple MacBook & MacBook Pro.
- Minor improvements and bug fixes.


**********************************************************************
*  3. Installation
**********************************************************************

The program is for Windows 10, Windows 8.1, Windows 8.0, Windows 7, 
Windows Server 2019, Windows Server 2016, Windows Server 2012, and Windows Server 2008.

You don't need to uninstall previous version of SIW (if there are any).
To install or re-install SIW run siw-setup.exe



**********************************************************************
*  4. Copyright and Contact Information
**********************************************************************

SIW is written and supported by Gabriel Topala.
Home Page of SIW: https://www.gtopala.com
Contact us: https://www.gtopala.com/tss/contact-us.php
Email: siw@gtopala.com

**********************************************************************
Copyright (c) 2005-2019 Topala Software Solutions
**********************************************************************
